package vo;

public class DiaryVO {

}
