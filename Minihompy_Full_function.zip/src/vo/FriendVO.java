package vo;

public class FriendVO {

}
